const NoPage = () => {
  return <h1>Hello world</h1>;
};

export default NoPage;
